<?php
defined('_JEXEC') or die('Restricted access');
class HelloWorldController extends JControllerLegacy 
{
}
?>