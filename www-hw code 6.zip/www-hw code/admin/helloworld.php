<?php
echo "My PHP script!";
echo "Admin Hello World";
?>